# VST GOD — Electric Pantheon Library v0.1

Built for Prime's VST GOD / The God Realm prototype.

## What is inside

- 8 god profiles
- 32 launch presets
- 8 MIDI signature kits
- 24 generated MIDI files:
  - 8 chord progressions
  - 8 basslines
  - 8 melody starters
- Macro behavior map for the locked face controls:
  - ENERGY
  - DIVINITY
  - WIDTH
  - REALM

## Drop-in paths

Copy these into your app:

```txt
src/data/vstGodElectricPantheonLibrary.ts
src/lib/useVstGodLibrary.ts
```

Optional reference component:

```txt
src/lib/ElectricPantheonPanel.example.tsx
```

Raw metadata:

```txt
metadata/vst-god-electric-pantheon-library.json
metadata/macro-behavior-map.json
```

MIDI:

```txt
midi/chord-progressions/*.mid
midi/basslines/*.mid
midi/melodies/*.mid
```

## Recommended first wiring

1. Replace the hardcoded Olympus data in the Electric Pantheon tab with `selectedPreset` and `selectedGod`.
2. Connect the left Pantheon buttons to `selectGod(god.id)`.
3. Connect preset arrows to `selectPreviousPreset()` and `selectNextPreset()`.
4. Use `selectedPreset.realmFx` to populate the Realm FX knobs.
5. Use `midiKit.chords`, `midiKit.voicings`, `midiKit.bass`, and `midiKit.melody` for sequencer/export previews.

## Preset count

Total presets: 32
Total gods: 8
Total MIDI kits: 8

## Product rule

Keep VST GOD separate from any customer session/audio runtime logic. This library is static signed content and metadata; it should not require live user data.

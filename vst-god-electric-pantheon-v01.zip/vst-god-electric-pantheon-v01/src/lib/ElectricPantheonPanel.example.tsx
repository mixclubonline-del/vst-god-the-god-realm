// Example integration snippet for your current VST GOD page.
// This is not required if your page is already wired; use it as a reference.
// Import useVstGodLibrary() and replace your hardcoded Olympus fields with selectedPreset/selectedGod.

import { useVstGodLibrary } from "../lib/useVstGodLibrary";
import { godProfiles } from "../data/vstGodElectricPantheonLibrary";

export function ElectricPantheonPanel() {
  const {
    selectedPreset,
    selectedGod,
    midiKit,
    macros,
    setMacro,
    selectGod,
    selectNextPreset,
    selectPreviousPreset,
  } = useVstGodLibrary();

  return (
    <section className="vst-god-electric-pantheon">
      <header>
        <button onClick={selectPreviousPreset}>◀</button>
        <div>
          <p>PRESET</p>
          <h2>{selectedPreset.displayName}</h2>
          <p>{selectedPreset.subtitle}</p>
        </div>
        <button onClick={selectNextPreset}>▶</button>
      </header>

      <aside>
        {godProfiles.map((god) => (
          <button key={god.id} onClick={() => selectGod(god.id)}>
            <span>{god.icon}</span>
            <strong>{god.name.toUpperCase()}</strong>
            <small>{god.subtitle}</small>
          </button>
        ))}
      </aside>

      <main>
        <h1>{selectedGod?.icon} {selectedGod?.name}</h1>
        <p>{selectedGod?.subtitle}</p>
        <em>"{selectedGod?.quote}"</em>

        <div>
          {selectedPreset.soundRecipe.map((item) => (
            <span key={item}>{item}</span>
          ))}
        </div>

        <div>
          {selectedPreset.realmFx.map((fx) => (
            <article key={fx.name}>
              <strong>{fx.name}</strong>
              <span>{Math.round(fx.default * 100)}%</span>
            </article>
          ))}
        </div>

        <div>
          <p>Chord kit: {midiKit?.chords.join(" → ")}</p>
          <p>BPM: {midiKit?.bpm} · Key: {midiKit?.key}</p>
        </div>

        {Object.entries(macros).map(([control, value]) => (
          <label key={control}>
            {control}
            <input
              type="range"
              min={0}
              max={1}
              step={0.01}
              value={value}
              onChange={(event) => setMacro(control as keyof typeof macros, Number(event.target.value))}
            />
          </label>
        ))}
      </main>
    </section>
  );
}

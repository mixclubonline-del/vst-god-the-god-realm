# Implementation Notes

## Suggested React state

```ts
const {
  selectedPreset,
  selectedGod,
  midiKit,
  macros,
  setMacro,
  selectGod,
  selectNextPreset,
  selectPreviousPreset,
} = useVstGodLibrary();
```

## Suggested audio mapping

- ENERGY → drive, transient, amp envelope attack, compression intensity
- DIVINITY → shimmer send, upper harmonic layer, chorus/glow, air EQ
- WIDTH → stereo width, chorus spread, micro-delay, reverb width
- REALM → FX-chain morph, texture layer, visual intensity, preset-specific identity

## Realm FX

Each preset includes four `realmFx` entries with default values. These can replace hardcoded FX labels like Heavenly Reverb / Gold Chorus depending on selected preset.

## MIDI export

The generated MIDI files are intentionally simple 4-bar starters. They are not meant to be full songs. They are seed kits so the VST feels alive immediately.

## Keep it clean

Do not overload the UI. The God Profile panel should show:
- Element
- Domain
- Energy
- Mood
- Best For
- Key Behavior
- Quote

Everything else can live in Export Lab, Parameter Stream, or State Matrix.
